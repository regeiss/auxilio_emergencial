import 'package:dio/dio.dart';
import 'package:gtk_flutter/source/features/responsavel/domain/responsavel.dart';

class ApiService {
  Future<List<Responsavel>> getResponsavel() async {
    try {
      String baseUrl = 'http://apireconstrucao.novohamburgo.rs.gov.br/api/buscar_responsaveis';
      var response = await Dio().get('$baseUrl/responsaveis');
      var responsaveis = (response.data as List);
      List<Responsavel> allUser = responsaveis.map((responsaveisData) => Responsavel.fromJson(responsaveisData)).toList();
      if (response.statusCode == 200) {
        return allUser;
      }
      return [];
    } on DioException catch (e) {
      return Future.error(e.message.toString());
    }
  }
}
